<?php
          session_start();
?>

<!-- Test Session Functions
     -->
<html xmlns = "http://www.w3.org/1999/xhtml">
  <head>
    <title> PHP sessions </title>
 
  
  </head>
  <body>
     <h1> Session started!</h1>  
  </body>
</html>

